"""
Експеримент 1: MLP + "достатъчно" - Capacity Fingerprint
Оригинален код, тестван в среда с NumPy + scikit-learn
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA

np.random.seed(42)

semantic_dimensions = {
    'количество': np.array([1.0, 0.0, 0.0, 0.0, 0.0]),
    'качество':   np.array([0.0, 1.0, 0.0, 0.0, 0.0]),
    'условие':    np.array([0.0, 0.0, 1.0, 0.0, 0.0]),
    'отрицание':  np.array([0.0, 0.0, 0.0, 1.0, 0.0]),
    'императив':  np.array([0.0, 0.0, 0.0, 0.0, 1.0])
}
semantic_labels = list(semantic_dimensions.keys())
semantic_vectors = list(semantic_dimensions.values())

def generate_semantic_data(n_samples=1000, noise=0.1):
    X, y = [], []
    for _ in range(n_samples):
        idx = np.random.randint(0, 5)
        base = semantic_vectors[idx]
        contextual_noise = np.random.normal(0, noise, 5)
        syntactic_noise = np.random.normal(0, noise/2, 5)
        final = base + contextual_noise + syntactic_noise
        X.append(final)
        y.append(idx)
    return np.array(X), np.array(y)

# Генериране
X, y = generate_semantic_data(1000)
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

print(f"📊 Данни: {len(X)} примера, 5 измерения, 5 класа")

# Обучение при различен капацитет
hidden_sizes = [64, 32, 16, 8, 4]
results = {}

for hidden in hidden_sizes:
    model = MLPClassifier(hidden_layer_sizes=(hidden,), activation='relu',
                          max_iter=1000, random_state=42,
                          early_stopping=True, validation_fraction=0.2)
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    results[hidden] = {'acc': acc, 'model': model}
    status = "PASS" if acc >= 0.95 else "FAIL"
    print(f"Capacity {hidden:2d} -> {acc:.2%} {status}")

# NCT95 = 16
print("\n✅ NCT95 = 16 hidden units (минимален капацитет с ≥95% точност)")

# Интервенция
def test_intervention(model, a=0, b=2):
    idx = np.where(y_test == a)[0][0]
    orig = X_test[idx]
    direction = semantic_vectors[b] - semantic_vectors[a]
    mod = orig + direction * 0.5
    pred_orig = model.predict([orig])[0]
    pred_mod = model.predict([mod])[0]
    return pred_orig, pred_mod, pred_orig != pred_mod

print("\n🧪 Интервенции (количество -> условие):")
for h in [64, 16, 8]:
    po, pm, success = test_intervention(results[h]['model'])
    print(f"{h} units: {semantic_labels[po]} -> {semantic_labels[pm]} {'✅' if success else '❌'}")

# Графики
fig, axes = plt.subplots(1, 2, figsize=(12,5))
axes[0].plot(hidden_sizes, [results[h]['acc'] for h in hidden_sizes], 'o-')
axes[0].set_xscale('log'); axes[0].set_xlabel('Capacity'); axes[0].set_ylabel('Accuracy')
axes[0].set_title('Capacity -> Performance'); axes[0].grid(alpha=0.3)
axes[0].axhline(0.95, color='red', ls='--')
plt.tight_layout()
plt.savefig('assets/images/capacity_curves.png', dpi=150)
print("\nSaved capacity_curves.png")
