"""
Пълен бенчмарк комбиниращ MLP + нови метрики + Llama симулация
"""

from nct_metrics_fixed import evaluate_nct_metrics, compute_centroids
import numpy as np
from sklearn.neural_network import MLPClassifier

# ... (комбинира логиката от двата експеримента)
# Виж NCT_Standalone_Offline.html за пълния код

if __name__ == "__main__":
    print("Пусни nct_experiment_1_mlp.py първо, после този файл за метрики")
