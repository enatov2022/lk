"""
Експеримент 2: Llama 3.2 + External Memory & Tools - NCT Benchmark
Оригинален код от потребителя - изисква GPU + HuggingFace
"""

import json
import re
import torch
from typing import Dict, Any, List
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

TASKS = [
    {
        "id": "task_1_memory_substitution",
        "category": "Memory",
        "probe": "Recall",
        "question": "Коя година е основана компанията ACME BioTech?",
        "context": "ACME BioTech е биотехнологична компания, основана през 2014 г. в София.",
        "expected_answer": "2014"
    },
    {
        "id": "task_2_computation_substitution",
        "category": "Computation",
        "probe": "Math/Tool",
        "question": "Колко е 387 умножено по 419?",
        "context": None,
        "tools_available": True,
        "expected_answer": "162153"
    },
    {
        "id": "task_3_coordination_and_semantics",
        "category": "Coordination",
        "probe": "Scope Operator ('само')",
        "question": "Кои служители имат достъп САМО до Сервер B?",
        "context": (
            "Иван има достъп до Сервер A и Сервер B. "
            "Мария има достъп само до Сервер B. "
            "Петър има достъп до Сервер C."
        ),
        "expected_answer": "Мария"
    }
]

def execute_tool(tool_name: str, args: str) -> str:
    if tool_name == "calculator":
        try:
            clean_expr = re.sub(r'[^0-9\+\-\*\/\.\(\)]', '', args)
            return str(eval(clean_expr))
        except Exception as e:
            return f"Error: {e}"
    return "Unknown tool"

class NCTRunner:
    def __init__(self, model_id: str):
        self.model_id = model_id
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)

    def load_model_variant(self, precision: str):
        print(f"\n[Зареждане на модел: {self.model_id} | Режим: {precision}]")
        
        if precision == "4bit":
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16
            )
            model = AutoModelForCausalLM.from_pretrained(
                self.model_id, quantization_config=bnb_config, device_map="auto"
            )
        elif precision == "8bit":
            model = AutoModelForCausalLM.from_pretrained(
                self.model_id, load_in_8bit=True, device_map="auto"
            )
        else:
            model = AutoModelForCausalLM.from_pretrained(
                self.model_id, torch_dtype=torch.float16, device_map="auto"
            )
        return model

    def run_eval(self, model, task: Dict[str, Any], use_external_resources: bool) -> bool:
        print("\n" + "="*60)
        print(f"[TASK] {task['id']} | Category: {task['category']} | Probe: {task['probe']}")
        print(f"[QUESTION] {task['question']}")
        if task.get("context"):
            print(f"[CONTEXT] {task['context']}")
        print(f"[EXPECTED] {task['expected_answer']}")
        print(f"[MODE] {'Externalized' if use_external_resources else 'Neural-Only'}")

        system_prompt = (
            "Анализирай въпроса и върни отговор в JSON формат: "
            "{\"thought\": \"...\", \"action\": \"none/calculator\", \"action_input\": \"...\", \"final_answer\": \"...\"}"
        )

        user_prompt = f"Въпрос: {task['question']}\n"
        if use_external_resources and task.get("context"):
            user_prompt += f"Контекст (External Memory): {task['context']}\n"

        full_prompt = f"{system_prompt}\n\n{user_prompt}\nОтговор:"

        inputs = self.tokenizer(full_prompt, return_tensors="pt").to(model.device)

        with torch.no_grad():
            outputs = model.generate(**inputs, max_new_tokens=150, temperature=0.1)

        response_text = self.tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)

        print("\n[RAW MODEL OUTPUT]")
        print(response_text)

        if use_external_resources and task.get("tools_available"):
            if "calculator" in response_text.lower():
                print("\n[TOOL DETECTED] Model requested calculator")
                match = re.search(r'(\d+[\*\+\-\/]\d+)', response_text)
                if match:
                    expr = match.group(1)
                    print(f"[EXTRACTED EXPRESSION] {expr}")
                    tool_result = execute_tool("calculator", expr)
                    print(f"[TOOL RESULT] {tool_result}")
                    followup_prompt = f"{full_prompt}\nИзползван инструмент: {tool_result}\nОкончателен отговор:"
                    inputs2 = self.tokenizer(followup_prompt, return_tensors="pt").to(model.device)
                    outputs2 = model.generate(**inputs2, max_new_tokens=50, temperature=0.1)
                    response_text = self.tokenizer.decode(outputs2[0][inputs2.input_ids.shape[1]:], skip_special_tokens=True)
                    print("\n[FINAL MODEL OUTPUT AFTER TOOL]")
                    print(response_text)

        is_correct = task["expected_answer"].lower() in response_text.lower()
        print(f"\n[RESULT] {'✔ CORRECT' if is_correct else '✘ WRONG'}")
        return is_correct

def run_nct_benchmark(model_id: str):
    runner = NCTRunner(model_id)
    precisions = ["FP16", "8bit", "4bit"]
    results = {}
    for prec in precisions:
        try:
            model = runner.load_model_variant(prec)
            results[prec] = {"neural_only": 0, "externalized": 0}
            total_tasks = len(TASKS)
            correct_no = sum(runner.run_eval(model, task, use_external_resources=False) for task in TASKS)
            results[prec]["neural_only"] = (correct_no / total_tasks) * 100
            correct_ext = sum(runner.run_eval(model, task, use_external_resources=True) for task in TASKS)
            results[prec]["externalized"] = (correct_ext / total_tasks) * 100
            del model
            torch.cuda.empty_cache()
        except Exception as e:
            print(f"[ERROR] Режим {prec}: {e}")

    print("\n" + "="*60)
    print(" РЕЗУЛТАТИ: NEURAL CAPACITY THRESHOLD (NCT)")
    print("="*60)
    print(f"{'Precision (Capacity)':<20} | {'Neural-Only Acc':<15} | {'Externalized Acc':<15}")
    print("-" * 54)
    for prec, accs in results.items():
        print(f"{prec:<20} | {accs['neural_only']:<14.1f}% | {accs['externalized']:<14.1f}%")

if __name__ == "__main__":
    for mid in ["meta-llama/Llama-3.2-1B", "meta-llama/Llama-3.2-3B"]:
        print("\n\n==============================")
        print(f"ТЕСТ НА МОДЕЛ: {mid}")
        print("==============================")
        run_nct_benchmark(mid)
