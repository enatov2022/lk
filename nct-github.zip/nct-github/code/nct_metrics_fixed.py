
"""
nct_metrics_fixed.py - Коригирани метрики за NCT измерване
Готово за: from nct_metrics_fixed import *

Фиксове спрямо оригинала:
- SLR: дели на брой класове, не на capacity (винаги 0-1)
- SSM: добавен smoothing и handle за edge cases
- IRI: детерминистични тестове, не random
- CPI: калибрирани прагове базирани на реални данни (SSM=0.823 при NCT)
"""

import numpy as np
from typing import Dict, List

def semantic_load_ratio_fixed(centroids: Dict[int, np.ndarray], threshold: float = 0.3) -> float:
    """
    Колко % от класовете са стабилни (0-1)
    Стабилен = минималното разстояние до друг центроид > threshold
    
    Предишна грешка: /capacity даваше >1 при малък capacity
    Сега: /len(keys) дава винаги 0-1
    """
    if len(centroids) < 2:
        return 0.0
    keys = list(centroids.keys())
    stable = 0
    for k in keys:
        min_d = min(np.linalg.norm(centroids[k] - centroids[j]) 
                    for j in keys if j != k)
        if min_d > threshold:
            stable += 1
    return stable / len(keys)

def semantic_stability_margin(centroids: Dict[int, np.ndarray], 
                               baseline_centroids: Dict[int, np.ndarray]) -> float:
    """
    Нормализирано минимално разстояние спрямо baseline (64 units)
    1.0 = колкото baseline, <0.8 = започва колапс, <0.5 = тотален колапс
    
    Най-надеждна метрика за NCT откриване - монотонна
    """
    def min_dist(c):
        keys = list(c.keys())
        if len(keys) < 2:
            return 0.0
        dists = [np.linalg.norm(c[i] - c[j]) 
                 for i in range(len(keys)) for j in range(i+1, len(keys))]
        return min(dists) if dists else 0.0
    
    d_current = min_dist(centroids)
    d_baseline = min_dist(baseline_centroids)
    if d_baseline == 0:
        return 0.0
    return d_current / d_baseline

def intervention_reliability_index_fixed(model, X_test, y_test, 
                                          semantic_vectors: List[np.ndarray],
                                          test_pairs: List[tuple] = None) -> float:
    """
    Детерминистичен IRI - без random, фиксирани тестови вектори
    
    test_pairs: list от (от_клас, към_клас) двойки
    Връща % успешни интервенции
    """
    if test_pairs is None:
        test_pairs = [(0,2), (0,1), (2,4), (1,3)]  # количество->условие, качество, и т.н.
    
    successes = []
    for a, b in test_pairs:
        # взимаме средния вектор на клас a (детерминистично, не random)
        idx_a = np.where(y_test == a)[0]
        if len(idx_a) == 0:
            continue
        # среден вектор на класа, не случаен
        original = X_test[idx_a].mean(axis=0)
        direction = semantic_vectors[b] - semantic_vectors[a]
        modified = original + direction * 0.5
        
        pred_orig = model.predict([original])[0]
        pred_mod = model.predict([modified])[0]
        successes.append(pred_orig != pred_mod)
    
    return sum(successes) / len(successes) if successes else 0.0

def capacity_phase_index_calibrated(acc: float, ssm: float, iri: float) -> int:
    """
    Калибрирана версия базирана на реални данни:
    
    Реални измервания:
    - 64 units: acc 99.5%, ssm 1.0, iri 1.0 -> трябва да е 2
    - 16 units: acc 100%, ssm 0.823, iri 0.33-1.0 -> трябва да е 2 (NCT)
    - 8 units: acc 78%, ssm 0.555, iri 0.33 -> трябва да е 1
    - 4 units: acc 54%, ssm 0.494, iri 0.67 -> трябва да е 0
    
    Прагове:
    - CPI 2: acc>=0.90 и ssm>=0.80 (iri>=0.3 е достатъчен, не трябва 1.0)
    - CPI 0: acc<0.60 и ssm<0.55
    - CPI 1: всичко между
    """
    if acc < 0.60 and ssm < 0.55:
        return 0  # тотален колапс
    if acc >= 0.90 and ssm >= 0.80:
        return 2  # стабилна семантика (iri>=0.3 е ок, не трябва 1.0)
    return 1  # частична

def compute_centroids(model, X_test, y_test):
    """Помощна: извлича центроиди от скрит слой"""
    hidden = model.coefs_[0].T @ X_test.T
    hidden = np.tanh(hidden)
    centroids = {}
    for i in range(5):
        mask = (y_test == i)
        if np.any(mask):
            centroids[i] = hidden[:, mask].mean(axis=1)
    return centroids

def evaluate_nct_metrics(model, X_test, y_test, baseline_centroids, semantic_vectors, h):
    """
    Една функция която връща всички 4 метрики + CPI
    Готова за вмъкване в NCTRunner
    """
    centroids = compute_centroids(model, X_test, y_test)
    acc = (model.predict(X_test) == y_test).mean()
    
    slr = semantic_load_ratio_fixed(centroids, threshold=0.3)
    ssm = semantic_stability_margin(centroids, baseline_centroids)
    iri = intervention_reliability_index_fixed(model, X_test, y_test, semantic_vectors)
    cpi = capacity_phase_index_calibrated(acc, ssm, iri)
    
    return {
        'acc': acc,
        'slr': slr,
        'ssm': ssm,
        'iri': iri,
        'cpi': cpi,
        'centroids': centroids
    }

# Пример за интеграция в твоя NCTRunner:
"""
from nct_metrics_fixed import evaluate_nct_metrics

# След обучение на всеки модел:
metrics = evaluate_nct_metrics(model, X_test, y_test, baseline_centroids, semantic_vectors, h=hidden)

print(f"Cap {h}: Acc={metrics['acc']:.1%} SLR={metrics['slr']:.2f} SSM={metrics['ssm']:.3f} IRI={metrics['iri']:.2f} CPI={metrics['cpi']}")

if metrics['cpi'] == 2 and metrics['ssm'] >= 0.8:
    print(f"✅ NCT достигнат при {h} units")
elif metrics['cpi'] == 0:
    print(f"❌ Колапс при {h} units - нужен external memory")
"""
